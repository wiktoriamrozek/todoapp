import express, { Request, Response } from 'express';
import bodyParser from 'body-parser';
import cors from 'cors';

const app = express();
const PORT = 5000;

app.use(bodyParser.json());
app.use(cors());

interface Todo {
  id: string;
  task: string;
  category: string;
  completed: boolean;
  isEditing: boolean;
}

let todos: Todo[] = [];

// Endpoint do pobierania wszystkich zadań
app.get('/todos', (req: Request, res: Response) => {
  res.json(todos);
});

// Endpoint do dodawania nowego zadania
app.post('/todos', (req: Request, res: Response) => {
  const newTodo: Todo = { id: Date.now().toString(), ...req.body };
  todos.push(newTodo);
  res.json(newTodo);
});

// Endpoint do usuwania zadania
app.delete('/todos/:id', (req: Request, res: Response) => {
  const { id } = req.params;
  todos = todos.filter(todo => todo.id !== id);
  res.sendStatus(204);
});

// Endpoint do edycji zadania
app.put('/todos/:id', (req: Request, res: Response) => {
  const { id } = req.params;
  const updatedTask: string = req.body.task;
  todos = todos.map(todo => (todo.id === id ? { ...todo, task: updatedTask } : todo));
  res.sendStatus(204);
});

app.listen(PORT, () => {
  console.log(`Server running on http://localhost:${PORT}`);
});
