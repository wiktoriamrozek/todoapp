import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import { TodoWrapper } from './components/TodoWrapper';
import { EditTodoForm } from './components/EditTodoForm';

const App: React.FC = () => {
  // Twoja funkcja obsługująca edycję zadania
  const yourEditTodoFunction = (task: string, id: string) => {
    // Tutaj dodaj logikę aktualizacji zadania
    console.log(`Aktualizacja zadania o id: ${id} na: ${task}`);
  };

  // Twój obiekt reprezentujący edytowane zadanie
  const yourTaskObject = { id: '1', task: 'Zadanie do edycji', completed: false, isEditing: true };

  return (
    <Router>
      <Routes>
        <Route
          path="/"
          element={<TodoWrapper />}
        />
        <Route
          path="/edit/:id"
          element={<EditTodoForm editTodo={yourEditTodoFunction} task={yourTaskObject} />}
        />
      </Routes>
    </Router>
  );
}

export default App;
