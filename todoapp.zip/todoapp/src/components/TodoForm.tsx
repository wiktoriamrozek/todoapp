import React, { useState, FormEvent } from 'react';
import { Form, Button } from 'react-bootstrap';

interface TodoFormProps {
  addTodo: (todo: { task: string; category: string }) => void;
}

export const TodoForm: React.FC<TodoFormProps> = ({ addTodo }) => {
  const [task, setTask] = useState('');
  const [category, setCategory] = useState('Dzienne');

  const handleSubmit = (e: FormEvent) => {
    e.preventDefault();
    if (task.trim() !== '') {
      addTodo({ task, category });
      setTask('');
      setCategory('Dzienne');
    }
  };

  return (
    <Form onSubmit={handleSubmit} className="TodoForm">
      <Form.Control
        type="text"
        value={task}
        onChange={(e) => setTask(e.target.value)}
        className="todo-input"
        placeholder="Co dzisiaj do zrobienia?"
      />
      <Form.Control
        as="select"
        value={category}
        onChange={(e) => setCategory(e.target.value)}
        className="todo-input"
      >
        <option value="Dzienne">Dzienne</option>
        <option value="Jednorazowe">Jednorazowe</option>
      </Form.Control>
      <Button type="submit" className="todo-btn">
        Dodaj zadanie
      </Button>
    </Form>
  );
};
