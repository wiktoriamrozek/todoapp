import React, { useState, FormEvent } from 'react';
import { useParams } from 'react-router-dom';

interface EditTodoFormProps {
  editTodo: (task: string, id: string) => void;
  task: { id: string; task: string; completed: boolean; isEditing: boolean };
}

export const EditTodoForm: React.FC<EditTodoFormProps> = ({ editTodo, task }) => {
  const [value, setValue] = useState(task.task);
  const { id } = useParams<{ id: string }>(); // Pobranie identyfikatora zadania z parametrów URL

  const handleSubmit = (e: FormEvent) => {
    e.preventDefault();
    if (value.trim() !== '') {
      editTodo(value, task.id);
    }
  };

  return (
    <form onSubmit={handleSubmit} className="TodoForm">
      <input
        type="text"
        value={value}
        onChange={(e) => setValue(e.target.value)}
        className="todo-input"
        placeholder="Update task"
      />
      <button type="submit" className="todo-btn">Update Task</button>
    </form>
  );
};
