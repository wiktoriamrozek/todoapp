import React, { useEffect } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { Todo } from './Todo';
import { TodoForm } from './TodoForm';
import { EditTodoForm } from './EditTodoForm';
import { RootState } from '../redux/store';
import { setTodos, addTodo, removeTodo, toggleComplete, editTodo, setEditing } from '../redux/todoSlice';

interface ITodo {
  id: string;
  task: string;
  category: string;
  completed: boolean;
  isEditing: boolean;
}

export const TodoWrapper: React.FC = () => {
  const dispatch = useDispatch();
  const todos = useSelector((state: RootState) => state.todos.todos);

  useEffect(() => {
    fetch('http://localhost:5000/todos')
      .then(res => res.json())
      .then(data => dispatch(setTodos(data)))
      .catch(err => console.error(err));
  }, [dispatch]);

  const handleAddTodo = (todo: Omit<ITodo, 'id' | 'completed' | 'isEditing'>) => {
    fetch('http://localhost:5000/todos', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(todo),
    })
      .then(res => res.json())
      .then(newTodo => dispatch(addTodo({ ...newTodo, completed: false, isEditing: false })))
      .catch(err => console.error(err));
  };

  const handleDeleteTodo = (id: string) => {
    fetch(`http://localhost:5000/todos/${id}`, { method: 'DELETE' })
      .then(() => dispatch(removeTodo(id)))
      .catch(err => console.error(err));
  };

  const handleToggleComplete = (id: string) => {
    dispatch(toggleComplete(id));
  };

  const handleEditTodo = (id: string) => {
    dispatch(setEditing(id));
  };

  const handleEditTask = (task: string, id: string) => {
    fetch(`http://localhost:5000/todos/${id}`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ task }),
    })
      .then(() => dispatch(editTodo({ id, task })))
      .catch(err => console.error(err));
  };

  return (
    <div className="TodoWrapper">
      <h1>To Do App!</h1>
      <TodoForm addTodo={handleAddTodo} />
      {todos.map(todo =>
        todo.isEditing ? (
          <EditTodoForm key={todo.id} editTodo={handleEditTask} task={todo} />
        ) : (
          <Todo
            key={todo.id}
            task={todo}
            deleteTodo={handleDeleteTodo}
            editTodo={handleEditTodo}
            toggleComplete={handleToggleComplete}
          />
        )
      )}
    </div>
  );
};
