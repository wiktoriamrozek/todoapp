import { createSlice, PayloadAction } from '@reduxjs/toolkit';

interface ITodo {
  id: string;
  task: string;
  category: string;
  completed: boolean;
  isEditing: boolean;
}

interface TodosState {
  todos: ITodo[];
}

const initialState: TodosState = {
  todos: [],
};

const todosSlice = createSlice({
  name: 'todos',
  initialState,
  reducers: {
    setTodos: (state, action: PayloadAction<ITodo[]>) => {
      state.todos = action.payload;
    },
    addTodo: (state, action: PayloadAction<ITodo>) => {
      state.todos.push(action.payload);
    },
    removeTodo: (state, action: PayloadAction<string>) => {
      state.todos = state.todos.filter(todo => todo.id !== action.payload);
    },
    toggleComplete: (state, action: PayloadAction<string>) => {
      const todo = state.todos.find(todo => todo.id === action.payload);
      if (todo) {
        todo.completed = !todo.completed;
      }
    },
    editTodo: (state, action: PayloadAction<{ id: string; task: string }>) => {
      const todo = state.todos.find(todo => todo.id === action.payload.id);
      if (todo) {
        todo.task = action.payload.task;
        todo.isEditing = false;
      }
    },
    setEditing: (state, action: PayloadAction<string>) => {
      const todo = state.todos.find(todo => todo.id === action.payload);
      if (todo) {
        todo.isEditing = !todo.isEditing;
      }
    },
  },
});

export const { setTodos, addTodo, removeTodo, toggleComplete, editTodo, setEditing } = todosSlice.actions;
export default todosSlice.reducer;
